appname: practice
Steps to install


1.pip install <practice.tar.gz>

Under settings.py add your app:
INSTALLED_APPS = [
   <appname>,
]

2.python manage.py migrate

4.Under project urls add app url
urlpattrens = (
	url (r'^<appname>',include('<appname>.urls')
)

3. To run django development server : python3 manage.py runserver
4.visist 127.0.0.1/practice

