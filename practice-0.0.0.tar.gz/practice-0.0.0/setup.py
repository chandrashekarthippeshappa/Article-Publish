from setuptools import find_packages,setup

setup (
	name="practice",
	Version = "1.0",
	description = "test app",
	packages = find_packages(),


	)